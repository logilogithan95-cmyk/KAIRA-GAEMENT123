// Example only. Do not put the Supabase service_role/secret key here.
// The website integration should use the Project URL and anon/public key.
window.KAIRA_SUPABASE_CONFIG = {
  url: "https://YOUR-PROJECT-REF.supabase.co",
  anonKey: "YOUR_SUPABASE_ANON_PUBLIC_KEY"
};
