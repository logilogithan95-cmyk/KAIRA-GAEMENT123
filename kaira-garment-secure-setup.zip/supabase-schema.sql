-- KAIRA GARMENT photo gallery schema for Supabase
-- Run in Supabase SQL Editor after creating an Auth user for the admin.

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;

-- Signed-in users can check whether their own account is an admin.
create policy "Admin can read own admin record"
on public.admin_users for select
to authenticated
using (auth.uid() = user_id);

create table if not exists public.gallery_photos (
  id uuid primary key default gen_random_uuid(),
  storage_path text not null unique,
  public_url text not null,
  alt_text text not null default 'KAIRA GARMENT jersey design',
  created_at timestamptz not null default now(),
  created_by uuid not null references auth.users(id)
);

alter table public.gallery_photos enable row level security;

create policy "Anyone can view gallery photos"
on public.gallery_photos for select
to anon, authenticated
using (true);

create policy "Admins can add gallery records"
on public.gallery_photos for insert
to authenticated
with check (
  auth.uid() = created_by
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

create policy "Admins can delete gallery records"
on public.gallery_photos for delete
to authenticated
using (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

-- Create a PUBLIC Storage bucket named exactly: kaira-photos
-- Supabase Dashboard → Storage → New bucket → kaira-photos → Public bucket ON.
-- Then run the storage policies below.

create policy "Public can view KAIRA photos"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'kaira-photos');

create policy "Admins can upload KAIRA photos"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'kaira-photos'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

create policy "Admins can delete KAIRA photos"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'kaira-photos'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);
