KAIRA GARMENT WEBSITE — பாதுகாப்பான Admin Setup

உங்கள் index.zip-ஐ ஆய்வு செய்ததில்:
- Website design, logo, product photos அனைத்தும் index.html-ல் embedded ஆக உள்ளன.
- தற்போதைய admin login browser-side JavaScript-ல் உள்ளது. இது உண்மையான secure login அல்ல.
- Admin status sessionStorage-ல் வைக்கப்படுகிறது; இதை browser-ல் மாற்ற முடியும்.
- Publish button window.claude artifact சேவையை நம்புகிறது; இது சாதாரண public hosting publish செயல்முறை அல்ல.

அதனால் பழைய login-ஐ வைத்து public-ஆக deploy செய்ய வேண்டாம்.

அடுத்த படி:
1. https://supabase.com இல் account/project உருவாக்கவும்.
2. Project-ல் Authentication → Users பகுதியில் admin user உருவாக்கவும் (email + வலுவான password).
3. Project URL மற்றும் anon/public key-ஐ Project Settings → API பகுதியில் எடுக்கவும்.
4. Supabase SQL Editor-ல் supabase-schema.sql உள்ள SQL-ஐ இயக்கவும்.
5. admin_users table-ல் admin user-ன் UUID-ஐ சேர்க்கவும். UUID-ஐ Authentication → Users-ல் காணலாம்.
6. கீழே உள்ள index.html-ஐ இன்னும் public-ஆக deploy செய்ய வேண்டாம்; அதில் தற்போதைய client-side login உள்ளது. Supabase URL/key மற்றும் admin UUID கிடைத்த பின் அதை பாதுகாப்பான auth/storage-க்கு இணைத்து, சோதித்து, பிறகு Vercel-ல் publish செய்யலாம்.

பாதுகாப்பு:
- உங்கள் admin password-ஐ ChatGPT-ல் அனுப்ப வேண்டாம்.
- anon/public key browser-ல் பயன்படுத்தப்படுவது சாதாரணம்; அதற்கான பாதுகாப்பு RLS policies-ல் இருக்க வேண்டும்.
- service_role/secret key-ஐ website HTML அல்லது JavaScript-ல் ஒருபோதும் வைக்க வேண்டாம்.
